package com.users.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.UserDaoImpl;
import com.db.db_connect;
import com.entity.users;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            // Create a UserDaoImpl instance with a database connection
            UserDaoImpl dao = new UserDaoImpl(db_connect.getConnection());
            
            // Get the user's email and password from the request
            String email = req.getParameter("email");
            String password = req.getParameter("password");

            if ("thaolt.21it@vku.udn.vn".equals(email) && "admin".equals(password)) {
                // If it's the admin user, set a user object in the session and redirect to admin home
                users adminUser = new users();
                HttpSession session = req.getSession();
                session.setAttribute("userobj", adminUser);
                resp.sendRedirect("admin/home.jsp");
            } else {
                // Attempt to login with the provided email and password
                users loggedInUser = dao.login(email, password);
                if (loggedInUser != null) {
                    // If login successful, set user object in the session and redirect to home
                    HttpSession session = req.getSession();
                    session.setAttribute("userobj", loggedInUser);
                    resp.sendRedirect("home.jsp");
                } else {
                    // If login fails, set an error message and redirect to login page
                    req.setAttribute("fail", "Invalid email and password");
                    req.getRequestDispatcher("login.jsp").forward(req, resp);
                }
            }
        } catch (Exception e) {
            // Handle any exceptions that occur during the login process
            e.printStackTrace(); // You might want to log the exception instead
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}
